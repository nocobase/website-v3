# Pages and interactions incremental source

This package follows the Data models and migrations and APIs and business services chapters. Its baseline is the app-tutorials 04-task-due-date example (25b8dd2, template1.0.0-beta.78) with BOTH preceding chapters already applied. It is not a standalone app, template upgrade, or deployment archive. No remote tag for this chapter is claimed.

Read the chapter before applying changes. Source files are under source/; inspect them and merge with application customizations. pages-and-interactions.patch is the exact diff against the chapter baseline captured before this work. Back up or commit your current work first. From your application root, run:

```bash
git apply --check /path/to/pages-and-interactions.patch
git apply /path/to/pages-and-interactions.patch
```

If the check fails, inspect and merge the corresponding source/ files instead. Do not force a patch or overwrite customized files. No new dependency or migration is introduced in this chapter. The preceding chapters must already have their migration and API registration in place.

All source/ files contain their complete resulting content. SOURCE-SHA256.txt lists hashes relative to source/. The patch is verified by applying it to the captured baseline and comparing every resulting file byte for byte.

Run the scoped commands documented in the article. Browser tests require a disposable local application and test credentials (TUTORIAL_USERNAME/TUTORIAL_PASSWORD); they create data. Their English full-window screenshots and temporary session go to ignored storage/ui-workflow/pages-and-interactions/. Delete auth.json after verification; never publish sessions or configuration. The sample test fallback account is for local development only.
