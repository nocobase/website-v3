import { useEffect, type RefObject } from 'react';
import { useNavigationGuard } from '@nocobase/app-client';

/** Keep the mounted form while a write is in flight, including history navigation. */
export function usePendingNavigation(
  pendingRef: RefObject<boolean>,
  pending: boolean,
) {
  useNavigationGuard(() => !pendingRef.current);
  useEffect(() => {
    if (!pending) return;
    const beforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', beforeUnload);
    return () => window.removeEventListener('beforeunload', beforeUnload);
  }, [pending]);
}
