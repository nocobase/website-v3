import { usePendingNavigation } from '#hooks/use-pending-navigation';
import { useMemo, useRef, useState } from 'react';
import { useOutletContext } from 'react-router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ApiClientError, useApiClient, useToaster } from '@nocobase/app-client';
import { useTranslation } from '@nocobase/i18n/client';
import { RouteDialog } from '#components/route-dialog';
import { useRouteOverlay } from '#components/use-route-overlay';
import { Button } from '#components/ui/button';
import { Field, FieldLabel, FieldError } from '#components/ui/field';
import { Input } from '#components/ui/input';
import { Spinner } from '#components/ui/spinner';
import { ProjectError } from './error.js';
import type { Project, ProjectsContext } from './types.js';
const FORM_ID = 'tutorial-project-create';
const violations = z.object({
  error: z.object({
    fieldViolations: z.array(
      z.object({ field: z.string(), reason: z.string().optional() }),
    ),
  }),
});
export default function CreateProjectPage() {
  const { t } = useTranslation();
  const [pending, setPending] = useState(false);
  const lockRef = useRef(false);
  usePendingNavigation(lockRef, pending);
  const submitting = (value: boolean) => {
    lockRef.current = value;
    setPending(value);
  };
  return (
    <RouteDialog
      title={t('projects.new')}
      description={t('projects.formDescription')}
      className='sm:max-w-md'
      beforeClose={() => !lockRef.current}
      footer={<Footer pending={pending} />}
    >
      <ProjectForm submitting={submitting} />
    </RouteDialog>
  );
}
function ProjectForm({ submitting }: { submitting: (value: boolean) => void }) {
  const { t } = useTranslation();
  const api = useApiClient();
  const toaster = useToaster();
  const { close } = useRouteOverlay();
  const { saved } = useOutletContext<ProjectsContext>();
  const [error, setError] = useState<unknown>();
  const composingRef = useRef(false);
  const lockRef = useRef(false);
  const schema = useMemo(
    () =>
      z.object({
        name: z
          .string()
          .trim()
          .min(1, t('projects.required'))
          .max(120, t('projects.tooLong')),
      }),
    [t],
  );
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: { name: '' },
  });
  async function submit(values: z.infer<typeof schema>) {
    if (lockRef.current || composingRef.current) return;
    lockRef.current = true;
    submitting(true);
    setError(undefined);
    try {
      const { data } = await api.request<{ data: Project }>({
        path: 'tutorialProjects',
        method: 'POST',
        json: values,
      });
      saved(data);
      toaster.show({
        type: 'success',
        title: t('projects.created', { name: data.name }),
      });
      submitting(false);
      await close();
    } catch (cause: unknown) {
      const parsed =
        cause instanceof ApiClientError && cause.status === 400
          ? violations.safeParse(cause.payload)
          : undefined;
      const field = parsed?.success
        ? parsed.data.error.fieldViolations.find((v) => v.field === 'name')
        : undefined;
      if (field)
        form.setError(
          'name',
          {
            type: 'server',
            message: t(
              field.reason === 'too_small'
                ? 'projects.required'
                : field.reason === 'too_big'
                  ? 'projects.tooLong'
                  : 'projects.invalidInput',
            ),
          },
          { shouldFocus: true },
        );
      else setError(cause);
    } finally {
      lockRef.current = false;
      submitting(false);
    }
  }
  return (
    <form
      id={FORM_ID}
      noValidate
      onSubmit={(event) => {
        void form.handleSubmit(submit)(event);
      }}
      className='flex flex-col gap-4'
      onKeyDown={(event) => {
        if (
          event.key === 'Enter' &&
          (event.nativeEvent.isComposing || composingRef.current)
        )
          event.preventDefault();
      }}
    >
      {error ? <ProjectError error={error} /> : null}
      <Field data-invalid={!!form.formState.errors.name}>
        <FieldLabel htmlFor='project-name'>{t('projects.name')} *</FieldLabel>
        <Input
          id='project-name'
          autoComplete='off'
          aria-required
          aria-invalid={!!form.formState.errors.name}
          aria-describedby={
            form.formState.errors.name ? 'project-name-error' : undefined
          }
          readOnly={form.formState.isSubmitting}
          {...form.register('name')}
          onCompositionStart={() => {
            composingRef.current = true;
          }}
          onCompositionEnd={() => {
            composingRef.current = false;
          }}
        />
        {form.formState.errors.name ? (
          <FieldError id='project-name-error'>
            {form.formState.errors.name.message}
          </FieldError>
        ) : null}
      </Field>
    </form>
  );
}
function Footer({ pending }: { pending: boolean }) {
  const { t } = useTranslation();
  const { close } = useRouteOverlay();
  return (
    <>
      <Button variant='outline' disabled={pending} onClick={() => void close()}>
        {t('tasks.cancel')}
      </Button>
      <Button type='submit' form={FORM_ID} disabled={pending}>
        {pending ? <Spinner data-icon='inline-start' /> : null}
        {t('tasks.create')}
      </Button>
    </>
  );
}
