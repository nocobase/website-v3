import { ApiClientError } from '@nocobase/app-client';
import { useAuthentication } from '@nocobase/app-plugin-authentication/client';
import { useTranslation } from '@nocobase/i18n/client';
import { Alert, AlertDescription } from '#components/ui/alert';
import { Button } from '#components/ui/button';

export function ProjectError({
  error,
  retry,
}: {
  error: unknown;
  retry?: () => void;
}) {
  const { t } = useTranslation();
  const { refresh } = useAuthentication();
  const status = error instanceof ApiClientError ? error.status : undefined;
  return (
    <Alert variant='destructive'>
      <AlertDescription>
        {t(
          status === 401
            ? 'tasks.sessionExpired'
            : status === 403
              ? 'tasks.forbidden'
              : status === 404
                ? 'projects.notFound'
                : status === 400
                  ? 'projects.invalidInput'
                  : 'tasks.requestFailed',
        )}
        {status === 401 ? (
          <Button variant='outline' onClick={() => void refresh()}>
            {t('tasks.signIn')}
          </Button>
        ) : null}
        {retry && (!status || status >= 500) ? (
          <Button variant='outline' onClick={retry}>
            {t('tasks.retry')}
          </Button>
        ) : null}
      </AlertDescription>
    </Alert>
  );
}
