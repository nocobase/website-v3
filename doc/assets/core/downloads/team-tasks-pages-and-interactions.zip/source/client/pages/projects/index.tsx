import { ApiClientError, useApiClient } from '@nocobase/app-client';
import { useCan } from '@nocobase/app-plugin-authorization/client';
import { useLocale, useTranslation } from '@nocobase/i18n/client';
import type { ColumnDef } from '@tanstack/react-table';
import { FolderKanban, Plus } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router';
import { DataTable, DataTableColumnHeader } from '#components/data-table';
import { PageContainer } from '#components/page-container';
import { PageHeader } from '#components/page-header';
import { Button } from '#components/ui/button';
import { Alert, AlertDescription } from '#components/ui/alert';
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '#components/ui/empty';
import { Input } from '#components/ui/input';
import { Skeleton } from '#components/ui/skeleton';
import { Spinner } from '#components/ui/spinner';
import { useUrlSearch } from '#hooks/use-url-search';
import { useTableUrlState } from '#hooks/use-table-url-state';
import { ProjectError } from './error.js';
import type { Project, ProjectsContext } from './types.js';

export default function ProjectsPage() {
  const { t } = useTranslation();
  const { locale } = useLocale();
  const api = useApiClient();
  const location = useLocation();
  const { searchParams, search, text, inputProps, clear } = useUrlSearch({
    resetParams: ['page'],
  });
  const access = useCan({
    resource: { type: 'composite', id: 'tutorial.projects' },
    action: 'create',
  });
  const [result, setResult] = useState<{
    data: Project[];
    meta: { total: number };
    key: string;
    filtered: boolean;
  }>();
  const [failure, setFailure] = useState<{ key: string; cause: unknown }>();
  const [revision, setRevision] = useState(0);
  const [savedOutside, setSavedOutside] = useState<Project>();
  const order = searchParams.get('order') === 'asc' ? 'asc' : 'desc';
  const key = JSON.stringify([
    search,
    searchParams.get('page'),
    searchParams.get('pageSize'),
    order,
    revision,
  ]);
  const loading = result?.key !== key && failure?.key !== key;
  const error = failure?.key === key ? failure.cause : undefined;
  const table = useTableUrlState({
    sortColumns: ['createdAt'],
    rowCount:
      !loading && !error && result?.key === key ? result.meta.total : undefined,
  });
  const { pageIndex, pageSize } = table.paginationState;
  const headingRef = useRef<HTMLSpanElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const previousPathRef = useRef(location.pathname);
  const reload = () => {
    setFailure(undefined);
    setRevision((v) => v + 1);
  };
  const clearFilters = () => {
    clear();
    searchRef.current?.focus();
  };
  useEffect(() => {
    const controller = new AbortController();
    void api
      .request<{ data: Project[]; meta: { total: number } }>({
        path: 'tutorialProjects',
        query: { q: search, order, page: pageIndex + 1, pageSize },
        signal: controller.signal,
      })
      .then((data) => {
        if (!controller.signal.aborted)
          setResult({ ...data, key, filtered: Boolean(search) });
      })
      .catch((cause: unknown) => {
        if (!controller.signal.aborted) {
          setFailure({ key, cause });
          if (
            cause instanceof ApiClientError &&
            [401, 403].includes(cause.status)
          )
            setResult(undefined);
        }
      });
    return () => controller.abort();
  }, [api, key, search, order, pageIndex, pageSize]);
  useEffect(() => {
    if (
      previousPathRef.current.endsWith('/create') &&
      !location.pathname.endsWith('/create')
    ) {
      const timer = setTimeout(() => {
        if (
          document.activeElement === document.body ||
          !document.activeElement?.isConnected
        )
          headingRef.current?.focus();
      }, 0);
      previousPathRef.current = location.pathname;
      return () => clearTimeout(timer);
    }
    previousPathRef.current = location.pathname;
  }, [location.pathname]);
  function saved(project: Project) {
    const visible =
      pageIndex === 0 &&
      order === 'desc' &&
      (!search ||
        project.name.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
    setSavedOutside(visible ? undefined : project);
    if (visible)
      setResult((old) =>
        old
          ? {
              ...old,
              data: [project, ...old.data].slice(0, pageSize),
              meta: { total: old.meta.total + 1 },
            }
          : old,
      );
    reload();
  }
  const newProject = access.can ? (
    <Button
      nativeButton={false}
      render={<Link to={{ pathname: 'create', search: location.search }} />}
    >
      <Plus data-icon='inline-start' />
      {t('projects.new')}
    </Button>
  ) : null;
  const columns: ColumnDef<Project>[] = [
    {
      accessorKey: 'name',
      header: t('projects.name'),
      enableSorting: false,
      cell: ({ row }) => <ProjectName name={row.original.name} />,
    },
    {
      accessorKey: 'createdAt',
      enableHiding: false,
      header: ({ column }) => (
        <DataTableColumnHeader
          column={column}
          title={t('projects.createdAt')}
        />
      ),
      cell: ({ row }) => (
        <time dateTime={row.original.createdAt}>
          {new Intl.DateTimeFormat(locale, {
            dateStyle: 'medium',
            timeStyle: 'short',
          }).format(new Date(row.original.createdAt))}
        </time>
      ),
    },
  ];
  const context: ProjectsContext = { saved };
  return (
    <PageContainer>
      <PageHeader
        title={
          <span ref={headingRef} tabIndex={-1}>
            {t('projects.title')}
          </span>
        }
        description={t('projects.description')}
        actions={
          result && (result.meta.total > 0 || result.filtered)
            ? newProject
            : null
        }
      />
      <div className='flex flex-wrap items-center gap-2'>
        <Input
          ref={searchRef}
          {...inputProps}
          maxLength={120}
          aria-label={t('projects.search')}
          placeholder={t('projects.search')}
          className='w-full sm:w-72'
        />
        {text ? (
          <Button variant='ghost' onClick={clearFilters}>
            {t('tasks.clearFilters')}
          </Button>
        ) : null}
      </div>
      {savedOutside ? (
        <Alert>
          <AlertDescription>
            {t('projects.savedOutside', { name: savedOutside.name })}
            <Button
              variant='outline'
              onClick={() => {
                clear((params) => {
                  params.delete('page');
                  params.set('order', 'desc');
                });
                setSavedOutside(undefined);
              }}
            >
              {t('projects.showLatest')}
            </Button>
          </AlertDescription>
        </Alert>
      ) : null}
      {access.error ? (
        <ProjectError error={access.error} retry={access.retry} />
      ) : null}
      {error ? <ProjectError error={error} retry={reload} /> : null}
      {loading ? (
        <div
          role='status'
          aria-label={t('tasks.loading')}
          className='flex flex-col gap-4'
        >
          {result ? (
            <div className='flex items-center gap-2 text-sm text-muted-foreground'>
              <Spinner />
              {t('tasks.loading')}
            </div>
          ) : (
            <>
              <Skeleton className='h-10 w-full' />
              <Skeleton className='h-10 w-full' />
              <Skeleton className='h-10 w-full' />
            </>
          )}
        </div>
      ) : null}
      {result?.meta.total === 0 && !result.filtered && !loading && !error ? (
        <Empty className='min-h-48 border border-dashed'>
          <EmptyHeader>
            <EmptyMedia variant='icon'>
              <FolderKanban />
            </EmptyMedia>
            <EmptyTitle>{t('projects.emptyTitle')}</EmptyTitle>
            <EmptyDescription>
              {t(
                access.can ? 'projects.emptyDescription' : 'projects.askAdmin',
              )}
            </EmptyDescription>
          </EmptyHeader>
          {newProject ? <EmptyContent>{newProject}</EmptyContent> : null}
        </Empty>
      ) : null}
      {result && (result.meta.total > 0 || result.filtered) ? (
        <DataTable
          columns={columns}
          data={result.data}
          {...table}
          sortingState={[{ id: 'createdAt', desc: order === 'desc' }]}
          manualPagination
          manualSorting
          rowCount={result.meta.total}
          loading={loading || Boolean(error)}
          showSelectedCount={false}
          emptyMessage={t('projects.noResults')}
          getRowId={(row) => row.id}
        />
      ) : null}
      <Outlet context={context} />
    </PageContainer>
  );
}
function ProjectName({ name }: { name: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [truncated, setTruncated] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new ResizeObserver(() =>
      setTruncated(node.scrollWidth > node.clientWidth),
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [name]);
  return (
    <span
      ref={ref}
      className='block max-w-xs truncate font-medium'
      title={truncated ? name : undefined}
    >
      {name}
    </span>
  );
}
