export interface Project {
  id: string;
  name: string;
  createdAt: string;
}
export interface ProjectsContext {
  saved: (project: Project) => void;
}
export interface ProjectEditor {
  data: {
    task: {
      id: string;
      title: string;
      projectId: string | null;
      projectName: string | null;
    };
    options: Project[];
  };
  meta: { page: number; pageSize: number; total: number };
}
