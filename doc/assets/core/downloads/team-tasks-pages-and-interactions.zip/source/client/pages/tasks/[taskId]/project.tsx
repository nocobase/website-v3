import { usePendingNavigation } from '#hooks/use-pending-navigation';
import { useEffect, useEffectEvent, useRef, useState } from 'react';
import { useOutletContext, useParams } from 'react-router';
import { z } from 'zod';
import { ApiClientError, useApiClient, useToaster } from '@nocobase/app-client';
import { useLocale, useTranslation } from '@nocobase/i18n/client';
import { RouteDialog } from '#components/route-dialog';
import { useRouteOverlay } from '#components/use-route-overlay';
import { Button } from '#components/ui/button';
import { Field, FieldLabel, FieldError } from '#components/ui/field';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '#components/ui/select';
import { Skeleton } from '#components/ui/skeleton';
import { Spinner } from '#components/ui/spinner';
import { ProjectError } from '../../projects/error.js';
import type { ProjectEditor } from '../../projects/types.js';
import type { TasksContext, TaskProject } from '../types.js';
const FORM_ID = 'tutorial-task-project';
const violations = z.object({
  error: z.object({
    fieldViolations: z.array(z.object({ field: z.string() })),
  }),
});
export default function TaskProjectPage() {
  const { t } = useTranslation();
  const { taskId } = useParams();
  const lockRef = useRef(false);
  const [state, setState] = useState({
    pending: false,
    disabled: true,
    terminal: false,
  });
  usePendingNavigation(lockRef, state.pending);
  return (
    <RouteDialog
      title={t('projects.changeProject')}
      beforeClose={() => !lockRef.current}
      footer={<Footer {...state} />}
    >
      <ProjectForm key={taskId} onState={setState} lockRef={lockRef} />
    </RouteDialog>
  );
}
function ProjectForm({
  onState,
  lockRef,
}: {
  onState: (value: {
    pending: boolean;
    disabled: boolean;
    terminal: boolean;
  }) => void;
  lockRef: React.RefObject<boolean>;
}) {
  const { taskId } = useParams();
  const { t } = useTranslation();
  const { locale } = useLocale();
  const api = useApiClient();
  const toaster = useToaster();
  const { close } = useRouteOverlay();
  const context = useOutletContext<TasksContext>();
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [result, setResult] = useState<ProjectEditor>();
  const [loadedKey, setLoadedKey] = useState('');
  const [failure, setFailure] = useState<{ key: string; cause: unknown }>();
  const [submitError, setSubmitError] = useState<unknown>();
  const [draft, setDraft] = useState<{
    original: string | null;
    value: string | null;
    label: string | null;
    title: string;
  }>();
  const [pending, setPending] = useState(false);
  const [fieldError, setFieldError] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const key = JSON.stringify([taskId, page, revision]);
  const error = failure?.key === key ? failure.cause : undefined;
  const loading = loadedKey !== key && !error;
  const effectiveError = submitError ?? error;
  const terminal =
    effectiveError instanceof ApiClientError && effectiveError.status === 404;
  const forbidden =
    effectiveError instanceof ApiClientError &&
    [401, 403].includes(effectiveError.status);
  const unchanged = draft?.value === draft?.original;
  const missing = useEffectEvent(() => context.projectMissing());
  const stateChanged = useEffectEvent(onState);
  useEffect(() => {
    stateChanged({
      pending,
      disabled:
        pending ||
        loading ||
        Boolean(error) ||
        !draft ||
        unchanged ||
        terminal ||
        forbidden,
      terminal,
    });
  }, [pending, loading, error, draft, unchanged, terminal, forbidden]);
  useEffect(() => {
    if (terminal) missing();
  }, [terminal]);
  useEffect(() => {
    if (!fieldError || pending) return;
    // Base UI updates the trigger's disabled state after the Select root commits.
    const frame = requestAnimationFrame(() => triggerRef.current?.focus());
    return () => cancelAnimationFrame(frame);
  }, [fieldError, pending]);
  useEffect(() => {
    const controller = new AbortController();
    void api
      .request<ProjectEditor>({
        path: `tutorialTasks/${encodeURIComponent(taskId ?? '')}/project`,
        query: { page, pageSize: 20 },
        signal: controller.signal,
      })
      .then((value) => {
        if (controller.signal.aborted) return;
        setResult(value);
        setLoadedKey(key);
        setDraft(
          (old) =>
            old ?? {
              original: value.data.task.projectId,
              value: value.data.task.projectId,
              label: value.data.task.projectName,
              title: value.data.task.title,
            },
        );
        const last = Math.max(1, Math.ceil(value.meta.total / 20));
        if (page > last) setPage(last);
      })
      .catch((cause: unknown) => {
        if (!controller.signal.aborted) setFailure({ key, cause });
      });
    return () => controller.abort();
  }, [api, key, taskId, page]);
  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (
      lockRef.current ||
      loading ||
      error ||
      !draft ||
      unchanged ||
      terminal ||
      forbidden
    )
      return;
    lockRef.current = true;
    setPending(true);
    setSubmitError(undefined);
    setFieldError(false);
    try {
      const { data } = await api.request<{ data: TaskProject }>({
        path: `tutorialTasks/${encodeURIComponent(taskId ?? '')}/project`,
        method: 'PATCH',
        json: { projectId: draft.value },
      });
      context.projectSaved(data);
      toaster.show({
        type: 'success',
        title: t('projects.assigned', { title: draft.title }),
      });
      lockRef.current = false;
      setPending(false);
      await close();
    } catch (cause: unknown) {
      const parsed =
        cause instanceof ApiClientError && cause.status === 400
          ? violations.safeParse(cause.payload)
          : undefined;
      if (
        parsed?.success &&
        parsed.data.error.fieldViolations.some((v) => v.field === 'projectId')
      )
        setFieldError(true);
      else setSubmitError(cause);
    } finally {
      lockRef.current = false;
      setPending(false);
    }
  }
  const retry = () => {
    setSubmitError(undefined);
    setRevision((v) => v + 1);
  };
  const selectedOutside =
    draft?.value && !result?.data.options.some((p) => p.id === draft.value);
  const pages = Math.max(1, Math.ceil((result?.meta.total ?? 0) / 20));
  const number = new Intl.NumberFormat(locale);
  return (
    <form
      id={FORM_ID}
      noValidate
      onSubmit={(event) => void submit(event)}
      className='flex flex-col gap-4'
      onKeyDown={(event) => {
        if (event.key === 'Enter' && event.nativeEvent.isComposing)
          event.preventDefault();
      }}
    >
      {effectiveError ? (
        <ProjectError error={effectiveError} retry={retry} />
      ) : null}
      {loading ? (
        <div role='status' aria-label={t('tasks.loading')}>
          {draft ? (
            <div className='flex items-center gap-2 text-sm text-muted-foreground'>
              <Spinner />
              {t('tasks.loading')}
            </div>
          ) : (
            <Skeleton className='h-20 w-full' />
          )}
        </div>
      ) : null}
      {draft && !terminal && !forbidden ? (
        <>
          <p className='break-words text-sm text-muted-foreground'>
            {draft.title}
          </p>
          <Field data-invalid={fieldError}>
            <FieldLabel htmlFor='task-project'>
              {t('projects.project')}
            </FieldLabel>
            <Select
              value={draft.value ?? ''}
              disabled={pending || loading || Boolean(error)}
              onValueChange={(value, details) => {
                // Dynamic option registration can emit null; clearing is the explicit empty-string option.
                if (value === null) {
                  details.cancel();
                  return;
                }
                const id = value || null;
                const option = result?.data.options.find((p) => p.id === id);
                setDraft({
                  ...draft,
                  value: id,
                  label:
                    option?.name ?? (id === draft.value ? draft.label : null),
                });
                setFieldError(false);
              }}
            >
              <SelectTrigger
                id='task-project'
                ref={triggerRef}
                className='w-full'
                aria-invalid={fieldError}
                aria-describedby={fieldError ? 'task-project-error' : undefined}
              >
                <SelectValue>
                  {draft.value
                    ? (draft.label ?? t('projects.unavailable'))
                    : t('projects.noProject')}
                </SelectValue>
              </SelectTrigger>
              <SelectContent className='w-auto max-w-[min(var(--container-sm),var(--available-width))] min-w-(--anchor-width) [&_[data-slot=select-item]>:first-child]:whitespace-normal'>
                <SelectGroup>
                  <SelectItem value=''>{t('projects.noProject')}</SelectItem>
                  {selectedOutside ? (
                    <SelectItem value={draft.value!} disabled={!draft.label}>
                      {draft.label ?? t('projects.unavailable')}
                    </SelectItem>
                  ) : null}
                  {result?.data.options.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            {fieldError ? (
              <FieldError id='task-project-error'>
                {t('projects.projectInvalid')}
              </FieldError>
            ) : null}
          </Field>
          {result?.meta.total === 0 ? (
            <p className='text-sm text-muted-foreground'>
              {t('projects.emptyOptions')}
            </p>
          ) : null}
          {result ? (
            <div className='flex flex-wrap items-center justify-between gap-2'>
              <p className='text-sm text-muted-foreground'>
                {t('projects.optionPages', {
                  page: number.format(page),
                  pages: number.format(pages),
                  total: number.format(result.meta.total),
                })}
              </p>
              <div className='flex gap-2'>
                <Button
                  type='button'
                  variant='outline'
                  disabled={pending || loading || page === 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  {t('projects.previous')}
                </Button>
                <Button
                  type='button'
                  variant='outline'
                  disabled={pending || loading || page >= pages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  {t('projects.next')}
                </Button>
              </div>
            </div>
          ) : null}
          {unchanged ? (
            <p className='text-sm text-muted-foreground'>
              {t('projects.unchanged')}
            </p>
          ) : null}
        </>
      ) : null}
    </form>
  );
}
function Footer({
  pending,
  disabled,
  terminal,
}: {
  pending: boolean;
  disabled: boolean;
  terminal: boolean;
}) {
  const { t } = useTranslation();
  const { close } = useRouteOverlay();
  return (
    <>
      <Button variant='outline' disabled={pending} onClick={() => void close()}>
        {t(terminal ? 'projects.close' : 'tasks.cancel')}
      </Button>
      {!terminal ? (
        <Button type='submit' form={FORM_ID} disabled={disabled}>
          {pending ? <Spinner data-icon='inline-start' /> : null}
          {t('projects.save')}
        </Button>
      ) : null}
    </>
  );
}
