export interface Task {
  id: string;
  projectId: string | null;
  title: string;
  completed: boolean;
  updatedAt: string;
  assigneeId: string | null;
  assigneeName: string | null;
  dueDate: string | null;
}

export interface TasksContext {
  saved: (task: Task, created?: boolean) => void;
  focusHeading: () => void;
  projectSaved: (task: TaskProject) => void;
  projectMissing: () => void;
}

export type TaskProject = Pick<Task, 'id' | 'projectId' | 'updatedAt'>;
