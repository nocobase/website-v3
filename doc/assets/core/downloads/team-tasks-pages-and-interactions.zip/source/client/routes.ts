import systemSettingsRoutes from './pages/settings/routes.js';
import { Home, ListTodo, FolderKanban } from 'lucide-react';
import {
  defineAppRoutes,
  type AppClientRouteContribution,
} from '@nocobase/app-client/plugins';

const appRoutes: AppClientRouteContribution = defineAppRoutes([
  {
    name: 'projects',
    path: '/projects',
    auth: 'required',
    authz: { resource: { type: 'page', id: 'projects' }, action: 'access' },
    navigation: { title: 'projects.title', icon: FolderKanban },
    breadcrumb: { title: 'projects.title' },
    componentLoader: () => import('./pages/projects/index.js'),
    children: [
      {
        name: 'projectCreate',
        path: 'create',
        authz: {
          resource: { type: 'composite', id: 'tutorial.projects' },
          action: 'create',
        },
        breadcrumb: { title: 'projects.new' },
        componentLoader: () => import('./pages/projects/create.js'),
      },
    ],
  },
  {
    name: 'tasks',
    path: '/tasks',
    auth: 'required',
    authz: { resource: { type: 'page', id: 'tasks' }, action: 'access' },
    navigation: { title: 'tasks.title', icon: ListTodo },
    breadcrumb: { title: 'tasks.title' },
    componentLoader: () => import('./pages/tasks/index.js'),
    children: [
      {
        name: 'taskProject',
        path: ':taskId/project',
        authz: {
          resource: { type: 'composite', id: 'tutorial.projects' },
          action: 'assignTask',
        },
        breadcrumb: { title: 'projects.changeProject' },
        componentLoader: () => import('./pages/tasks/[taskId]/project.js'),
      },
      {
        name: 'taskCreate',
        path: 'create',
        authz: {
          resource: { type: 'composite', id: 'tutorial.tasks' },
          action: 'create',
        },
        breadcrumb: { title: 'tasks.new' },
        componentLoader: () => import('./pages/tasks/create.js'),
      },
    ],
  },
  {
    // Every signed-in user reaches the landing page. `authz: 'skip'` takes it out of page authorization entirely, so
    // no permission change can leave a user signed in with nowhere to land.
    authz: 'skip',
    auth: 'required',
    componentLoader: () => import('./pages/home/index.js'),
    name: 'home',
    navigation: { title: 'navigation.home', icon: Home },
    path: '/',
  },
  {
    // Declares no navigation, so the application decides where its entry goes (for example a sidebar item with an
    // unread badge). The plugin's API answers each person's own messages only, so the page needs no authorization of
    // its own.
    authz: 'skip',
    auth: 'required',
    componentLoader: () => import('./pages/inbox.js'),
    name: 'inbox',
    path: '/inbox',
  },
  {
    auth: 'guest',
    authz: 'skip',
    componentLoader: () => import('./pages/auth/login.js'),
    name: 'login',
    path: '/login',
  },
  {
    auth: 'guest',
    authz: 'skip',
    componentLoader: () => import('./pages/auth/register.js'),
    name: 'register',
    path: '/register',
  },
  {
    auth: 'guest',
    authz: 'skip',
    componentLoader: () => import('./pages/auth/forgot-password.js'),
    name: 'forgot-password',
    path: '/forgot-password',
  },
  {
    auth: 'guest',
    authz: 'skip',
    componentLoader: () => import('./pages/auth/reset-password.js'),
    name: 'reset-password',
    path: '/reset-password',
  },
  {
    // Where a command line's sign-in sends the person to approve it (`pages/auth/device.tsx`). Optional rather than
    // required so it renders outside the shell, like the sign-in pages; the page sends a guest to sign in and back.
    auth: 'optional',
    authz: 'skip',
    componentLoader: () => import('./pages/auth/device.js'),
    name: 'device',
    path: '/device',
  },
]);

const routes: readonly AppClientRouteContribution[] = [
  appRoutes,
  systemSettingsRoutes,
];

export default routes;
