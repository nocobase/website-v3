import { randomUUID } from 'node:crypto';
import type {
  DatabaseManager,
  RepositoryPolicy,
  RepositoryFilter,
} from '@nocobase/db';

export interface ProjectView {
  id: string;
  name: string;
  createdAt: string;
}
export interface TaskProjectView {
  id: string;
  projectId: string | null;
  updatedAt: string;
}
export class ProjectUnavailableError extends Error {
  constructor() {
    super('The selected project is unavailable.');
  }
}
export class TaskUnavailableError extends Error {
  constructor() {
    super('The task is unavailable.');
  }
}
const projectView = (row: Record<string, unknown>): ProjectView => ({
  id: String(row.id),
  name: String(row.name),
  createdAt: new Date(row.createdAt as string | Date).toISOString(),
});

export class TutorialProjectService {
  constructor(private readonly database: DatabaseManager) {}

  async list(
    policy: RepositoryPolicy,
    input: {
      page: number;
      pageSize: number;
      q?: string;
      order?: 'asc' | 'desc';
    },
  ) {
    const projects = this.database
      .repository('tutorialProjects')
      .withPolicy(policy);
    const filter: RepositoryFilter<Record<string, unknown>> = (f) =>
      f.and(input.q ? [f.string('name').includes(input.q)] : []);
    const rows = await projects.findMany({
      filter,
      select: (s) => s.fields('id', 'name', 'createdAt'),
      limit: input.pageSize,
      offset: (input.page - 1) * input.pageSize,
      sort: (s) =>
        input.order === 'asc'
          ? [s.field('createdAt').asc(), s.field('id').asc()]
          : [s.field('createdAt').desc(), s.field('id').desc()],
    });
    return {
      data: rows.map(projectView),
      meta: {
        page: input.page,
        pageSize: input.pageSize,
        total: await projects.count({ filter }),
      },
    };
  }

  async editor(
    policies: { tasks: RepositoryPolicy; projects: RepositoryPolicy },
    taskId: string,
    input: { page: number; pageSize: number },
  ) {
    const task = await this.database
      .repository('tutorialTasks')
      .withPolicy(policies.tasks)
      .findOne({
        filter: { id: taskId },
        select: (s) => s.fields('id', 'title', 'projectId'),
      });
    if (!task) throw new TaskUnavailableError();
    const project = task.projectId
      ? await this.database
          .repository('tutorialProjects')
          .withPolicy(policies.projects)
          .findOne({
            filter: { id: String(task.projectId as string) },
            select: (s) => s.fields('id', 'name'),
          })
      : null;
    const options = await this.list(policies.projects, input);
    return {
      data: {
        task: {
          id: taskId,
          title: task.title as string,
          projectId: task.projectId as string | null,
          projectName: project ? (project.name as string) : null,
        },
        options: options.data,
      },
      meta: options.meta,
    };
  }

  async create(
    policy: RepositoryPolicy,
    input: { name: string },
  ): Promise<ProjectView> {
    const result = await this.database
      .repository('tutorialProjects')
      .withPolicy(policy)
      .createOne({
        select: (s) => s.fields('id', 'name', 'createdAt'),
        values: { id: randomUUID(), name: input.name, createdAt: new Date() },
      });
    return projectView(result.record);
  }

  async assignTask(
    policies: { tasks: RepositoryPolicy; projects: RepositoryPolicy },
    taskId: string,
    projectId: string | null,
  ): Promise<TaskProjectView> {
    return this.database.transaction(async (connection) => {
      const tasks = connection
        .repository('tutorialTasks')
        .withPolicy(policies.tasks);
      const task = await tasks.findOne({
        filter: { id: taskId },
        select: (s) => s.fields('id'),
      });
      if (!task) throw new TaskUnavailableError();
      if (projectId !== null) {
        const project = await connection
          .repository('tutorialProjects')
          .withPolicy(policies.projects)
          .findOne({
            filter: { id: projectId },
            select: (s) => s.fields('id'),
          });
        if (!project) throw new ProjectUnavailableError();
      }
      const result = await tasks.updateOne({
        select: (s) => s.fields('id', 'projectId', 'updatedAt'),
        filter: { id: taskId },
        values: { projectId, updatedAt: new Date() },
      });
      return {
        id: taskId,
        projectId: result.record.projectId as string | null,
        updatedAt: new Date(
          result.record.updatedAt as string | Date,
        ).toISOString(),
      };
    });
  }
}
