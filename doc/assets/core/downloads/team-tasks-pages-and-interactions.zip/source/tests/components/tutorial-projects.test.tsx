import { apiClientToken } from '@nocobase/app-client';
import {
  AuthenticationProvider,
  authenticationClientToken,
} from '@nocobase/app-plugin-authentication/client';
import {
  AuthorizationClient,
  authorizationClientToken,
} from '@nocobase/app-plugin-authorization/client';
import {
  answerApi,
  renderWithApp,
  type ApiCall,
} from '@nocobase/app-testing/client';
import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Route, Routes } from 'react-router';
import { beforeAll, afterAll, expect, it, vi } from 'vitest';

// jsdom has no layout observer; overflow behavior is verified in Chromium.
beforeAll(() =>
  vi.stubGlobal(
    'ResizeObserver',
    class {
      observe() {}
      disconnect() {}
      unobserve() {}
    },
  ),
);
afterAll(() => vi.unstubAllGlobals());
import metadata from '../../package.json' with { type: 'json' };
import enUS from '../../client/locales/en-US.js';
import Projects from '../../client/pages/projects/index.js';
import CreateProject from '../../client/pages/projects/create.js';

// Only transport/session boundaries are fixtures: delayed/failing responses cannot be made
// deterministic with a live server. Application hooks, forms, router and overlays stay real.
async function renderProjects(
  handler: (call: ApiCall) => unknown,
  route = '/projects',
  canCreate = true,
) {
  return renderWithApp(
    <AuthenticationProvider>
      <Routes>
        <Route path='/projects' element={<Projects />}>
          <Route path='create' element={<CreateProject />} />
        </Route>
      </Routes>
    </AuthenticationProvider>,
    {
      route,
      namespace: metadata.name,
      namespaces: { [metadata.name]: enUS },
      fetch: answerApi((call) =>
        call.path === 'authorization/permissions'
          ? {
              data: {
                unrestricted: false,
                permissions: canCreate
                  ? [
                      {
                        resource: {
                          type: 'composite',
                          id: 'tutorial.projects',
                        },
                        actions: ['create'],
                      },
                    ]
                  : [],
              },
            }
          : handler(call),
      ),
      services: (app) => {
        app.container.instance(authenticationClientToken, {
          getSession: async () => ({ data: null }),
        });
        app.container.singleton(
          authorizationClientToken,
          (r) => new AuthorizationClient(r.resolve(apiClientToken)),
        );
      },
    },
  );
}
const empty = { data: [], meta: { total: 0 } };
it('explains empty read-only data and keeps creation available for an empty search', async () => {
  const view = await renderProjects(() => empty, '/projects', false);
  expect(
    await screen.findByText(
      'Ask an administrator for permission to create projects.',
    ),
  ).toBeVisible();
  expect(screen.queryByRole('button', { name: 'New project' })).toBeNull();
  view.unmount();
  await renderProjects(() => empty, '/projects?q=missing');
  expect(
    await screen.findByText('No projects match your search.'),
  ).toBeVisible();
  expect(screen.getByRole('button', { name: 'New project' })).toBeVisible();
  expect(screen.getByRole('button', { name: 'Clear filters' })).toBeVisible();
});
it('associates server name errors with the field, preserves input and focuses it', async () => {
  const user = userEvent.setup();
  await renderProjects(
    (call) =>
      call.method === 'POST'
        ? new Response(
            JSON.stringify({
              error: {
                status: 'INVALID_ARGUMENT',
                message: 'Invalid name',
                fieldViolations: [{ field: 'name', reason: 'too_big' }],
              },
            }),
            { status: 400, headers: { 'content-type': 'application/json' } },
          )
        : empty,
    '/projects/create',
  );
  const input = await screen.findByLabelText('Name *');
  await user.type(input, 'Product launch');
  await user.click(screen.getByRole('button', { name: 'Create', exact: true }));
  await waitFor(() => expect(input).toHaveAttribute('aria-invalid', 'true'));
  expect(input).toHaveAttribute('aria-describedby', 'project-name-error');
  expect(input).toHaveValue('Product launch');
  expect(input).toHaveFocus();
});
it('keeps ascending rows and confirms a created record outside the current view', async () => {
  const user = userEvent.setup();
  let writes = 0;
  const first = {
    id: '11111111-1111-4111-8111-111111111111',
    name: 'Earlier project',
    createdAt: '2025-01-01T00:00:00Z',
  };
  await renderProjects((call) => {
    if (call.method === 'POST') {
      writes++;
      return {
        data: {
          ...first,
          id: '22222222-2222-4222-8222-222222222222',
          name: 'Later project',
          createdAt: '2026-01-01T00:00:00Z',
        },
      };
    }
    return { data: [first], meta: { total: 30 } };
  }, '/projects/create?order=asc');
  await user.type(await screen.findByLabelText('Name *'), 'Later project');
  await user.click(screen.getByRole('button', { name: 'Create', exact: true }));
  expect(
    await screen.findByText('"Later project" was created outside this view.'),
  ).toBeVisible();
  expect(screen.getByRole('cell', { name: 'Earlier project' })).toBeVisible();
  expect(screen.queryByRole('cell', { name: 'Later project' })).toBeNull();
  expect(writes).toBe(1);
});
it('offers retry for transient failures but not forbidden responses', async () => {
  const user = userEvent.setup();
  let status = 500;
  await renderProjects(
    () =>
      new Response(
        JSON.stringify({ error: { status: 'INTERNAL', message: 'Failure' } }),
        { status, headers: { 'content-type': 'application/json' } },
      ),
  );
  await user.click(await screen.findByRole('button', { name: 'Retry' }));
  status = 403;
  await user.click(await screen.findByRole('button', { name: 'Retry' }));
  expect(
    await screen.findByText(
      'You do not have permission. Contact an administrator.',
    ),
  ).toBeVisible();
  expect(screen.queryByRole('button', { name: 'Retry' })).toBeNull();
});
