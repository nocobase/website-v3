/// <reference lib="dom" />
import { test, expect, type Page } from '@playwright/test';
import { mkdir } from 'node:fs/promises';

const entry = process.env.APP_URL;
if (!entry) throw new Error('Set APP_URL to the full application entry URL.');
const appUrl = new URL(entry.endsWith('/') ? entry : `${entry}/`);
const artifact = 'storage/ui-workflow/pages-and-interactions';
test.use({
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 2,
  launchOptions: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
    ? {
        executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
        args: ['--no-sandbox'],
      }
    : {},
});
test('creates projects, preserves list context and changes task projects against the real server', async ({
  page,
}) => {
  await mkdir(`${artifact}/screenshots`, { recursive: true });
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(appUrl.href);
  await page
    .getByLabel('Username or email', { exact: true })
    .fill(process.env.TUTORIAL_USERNAME ?? 'nocobase');
  await page
    .getByLabel('Password', { exact: true })
    .fill(process.env.TUTORIAL_PASSWORD ?? 'admin123');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByRole('link', { name: 'Projects', exact: true }).click();
  await expect(
    page.getByRole('heading', { name: 'Projects', exact: true }),
  ).toBeVisible();
  // UI workflow baseline includes the shell's existing React script warning; collect thrown errors separately.
  const apiUrl = (path: string) => new URL(`api/${path}`, appUrl).href;
  const post = async (path: string, data: unknown) => {
    const response = await page.request.post(apiUrl(path), {
      data,
      headers: { origin: appUrl.origin },
    });
    expect(response.ok()).toBeTruthy();
    return (await response.json()).data;
  };
  const stamp = Date.now();
  const name = `Website launch ${stamp}`;
  await page.getByRole('button', { name: 'New project', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'New project', exact: true });
  const input = dialog.getByLabel('Name', { exact: false });
  await dialog.getByRole('button', { name: 'Create', exact: true }).click();
  await expect(input).toBeFocused();
  await expect(input).toHaveAttribute('aria-invalid', 'true');
  await input.pressSequentially(name);
  await input.press('Home');
  await input.press('ArrowRight');
  await input.press('Backspace');
  await input.pressSequentially('W');
  await expect(input).toHaveValue(name);
  await page.screenshot({
    path: `${artifact}/screenshots/create-project.png`,
    fullPage: false,
    animations: 'disabled',
  });
  // Change the outbound payload to exercise real server validation, without mocking a response.
  await page.route(apiUrl('tutorialProjects'), async (route) =>
    route.request().method() === 'POST'
      ? route.continue({ postData: JSON.stringify({ name: 'x'.repeat(121) }) })
      : route.continue(),
  );
  await dialog.getByRole('button', { name: 'Create', exact: true }).click();
  await expect(input).toHaveAttribute('aria-invalid', 'true');
  await expect(input).toBeFocused();
  await page.unroute(apiUrl('tutorialProjects'));
  await input.press('End');
  await input.press('Space');
  await input.press('Backspace');
  await saveWithNavigationLock(
    page,
    'New project',
    apiUrl('tutorialProjects'),
    'POST',
    'Create',
  );
  await expect(dialog).toHaveCount(0);
  await expect(page.getByRole('cell', { name, exact: true })).toBeVisible();
  const list = await (
    await page.request.get(
      apiUrl(`tutorialProjects?q=${encodeURIComponent(name)}`),
    )
  ).json();
  const projectId = list.data[0].id;
  await post('tutorialProjects', { name: 'Customer onboarding' });
  await post('tutorialProjects', { name: 'Documentation refresh' });
  await page.reload();
  await expect(
    page
      .getByRole('cell', { name: 'Documentation refresh', exact: true })
      .first(),
  ).toBeVisible();
  await page.screenshot({
    path: `${artifact}/screenshots/projects-list.png`,
    fullPage: false,
    animations: 'disabled',
  });
  const search = page.getByRole('textbox', { name: 'Search by project name' });
  await search.pressSequentially('No matching project');
  await expect(page.getByText('No projects match your search.')).toBeVisible();
  await expect(
    page.getByRole('button', { name: 'New project', exact: true }),
  ).toBeVisible();
  await page
    .getByRole('button', { name: 'Clear filters', exact: true })
    .click();
  // Chromium IME composition must not submit a form or replace the draft while composing.
  const cdp = await page.context().newCDPSession(page);
  await search.focus();
  await cdp.send('Input.imeSetComposition', {
    text: 'xiang',
    selectionStart: 5,
    selectionEnd: 5,
  });
  await expect(search).toHaveValue('xiang');
  await cdp.send('Input.insertText', { text: '项目' });
  await expect(search).toHaveValue('项目');
  await expect(page).toHaveURL(/q=/);
  await page
    .getByRole('button', { name: 'Clear filters', exact: true })
    .click();
  // More than one options page, with real records and no capped fallback.
  for (let i = 1; i <= 21; i++)
    await post('tutorialProjects', {
      name: `Planning project ${String(i).padStart(2, '0')}`,
    });
  const task = await post('tutorialTasks', {
    title: `Prepare website content ${stamp}`,
  });
  await page.goto(
    new URL(`tasks?q=${encodeURIComponent(task.title)}`, appUrl).href,
  );
  const row = page
    .getByRole('row')
    .filter({ has: page.getByRole('cell', { name: task.title, exact: true }) });
  await row.getByRole('button', { name: `Actions for ${task.title}` }).click();
  await page.screenshot({
    path: `${artifact}/screenshots/task-actions.png`,
    fullPage: false,
    animations: 'disabled',
  });
  await page
    .getByRole('menuitem', { name: 'Change project', exact: true })
    .click();
  const editor = page.getByRole('dialog', {
    name: 'Change project',
    exact: true,
  });
  const project = editor.getByRole('combobox', {
    name: 'Project',
    exact: true,
  });
  await expect(
    editor.getByRole('button', { name: 'Save', exact: true }),
  ).toBeDisabled();
  await editor.getByRole('button', { name: 'Next', exact: true }).click();
  await expect(editor.getByText(/page 2 of/)).toBeVisible();
  await project.click();
  await page.getByRole('option', { name, exact: true }).click();
  await editor.getByRole('button', { name: 'Previous', exact: true }).click();
  await expect(project).toContainText(name);
  await project.click();
  await page.screenshot({
    path: `${artifact}/screenshots/change-project.png`,
    fullPage: false,
    animations: 'disabled',
  });
  await page.keyboard.press('Escape');
  await page.route(apiUrl(`tutorialTasks/${task.id}/project`), async (route) =>
    route.request().method() === 'PATCH'
      ? route.continue({
          postData: JSON.stringify({
            projectId: '00000000-0000-4000-8000-000000000000',
          }),
        })
      : route.continue(),
  );
  await editor.getByRole('button', { name: 'Save', exact: true }).click();
  await expect(project).toHaveAttribute('aria-invalid', 'true');
  await expect(project).toBeFocused();
  await expect(project).toHaveAttribute(
    'aria-describedby',
    'task-project-error',
  );
  await page.screenshot({
    path: `${artifact}/screenshots/project-validation.png`,
    fullPage: false,
    animations: 'disabled',
  });
  await page.unroute(apiUrl(`tutorialTasks/${task.id}/project`));
  await saveWithNavigationLock(
    page,
    'Change project',
    apiUrl(`tutorialTasks/${task.id}/project`),
    'PATCH',
    'Save',
  );
  await expect(editor).toHaveCount(0);
  await expect(page).toHaveURL(/tasks\?q=/);
  const persisted = await (
    await page.request.get(apiUrl(`tutorialTasks/${task.id}/project`))
  ).json();
  expect(persisted.data.task.projectId).toBe(projectId);
  await page.reload();
  await row.getByRole('button', { name: `Actions for ${task.title}` }).click();
  await page
    .getByRole('menuitem', { name: 'Change project', exact: true })
    .click();
  await expect(project).toContainText(name);
  // Replacing an off-page current value must survive dynamic option registration.
  await project.click();
  await page
    .getByRole('option', { name: 'Planning project 21', exact: true })
    .click();
  await expect(project).toContainText('Planning project 21');
  await project.click();
  await page.getByRole('option', { name: 'No project', exact: true }).click();
  await editor.getByRole('button', { name: 'Save', exact: true }).click();
  await expect(editor).toHaveCount(0);
  expect(
    (
      await (
        await page.request.get(apiUrl(`tutorialTasks/${task.id}/project`))
      ).json()
    ).data.task.projectId,
  ).toBeNull();
  await page.context().storageState({ path: `${artifact}/auth.json` });
  expect(errors).toEqual([]);
});

async function saveWithNavigationLock(
  page: Page,
  title: string,
  api: string,
  method: string,
  label: string,
) {
  const dialog = page.getByRole('dialog', { name: title, exact: true });
  const url = page.url();
  let release!: () => void;
  let requests = 0;
  const held = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route(api, async (route) => {
    if (route.request().method() === method) {
      requests += 1;
      await held;
    }
    await route.continue();
  });
  try {
    await dialog.getByRole('button', { name: label, exact: true }).click();
    await expect(
      dialog.getByRole('button', { name: 'Cancel', exact: true }),
    ).toBeDisabled();
    await page.goBack();
    await expect(page).toHaveURL(url);
    await expect(dialog).toBeVisible();
    await page.keyboard.press('Escape');
    await dialog.getByRole('button', { name: 'Close', exact: true }).click();
    await page
      .locator('[data-slot="dialog-overlay"]')
      .click({ position: { x: 4, y: 4 } });
    await expect(dialog).toBeVisible();
    await page.keyboard.press('Enter');
    expect(requests).toBe(1);
  } finally {
    release();
  }
  await expect(dialog).toHaveCount(0);
  await page.unroute(api);
}
