import agentChat from '#extensions/nocobase-agent-chat/locales/zh-CN';
import fileUi from '../extensions/nocobase-file-component-ui/locales/zh-CN.js';
import type { AppResource } from './en-US.js';
import systemZhCN from './system/zh-CN.js';

const zhCN: AppResource = {
  // The template's own copy; see `./en-US.ts`.
  ...systemZhCN,
  ...fileUi,
  ...agentChat,
  agentDemo: {
    title: 'Agents',
    models: '模型',
    agents: '机器上的 Agent',
    runtimes: '运行环境',
    skills: 'Skills',
    usage: '用量',
  },
};

export default zhCN;
