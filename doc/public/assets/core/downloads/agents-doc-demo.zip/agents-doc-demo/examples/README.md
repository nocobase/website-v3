# Agents documentation example

Verified on 2026-10-29 with Node.js 24, pnpm 11, the default App template
1.0.0-beta.84, and @nocobase/app-plugin-agents 1.0.0-beta.29.

## Start a fresh copy

From the extracted application's root:

```bash
pnpm install --frozen-lockfile
pnpm nocobase config init --dialect sqlite
pnpm nocobase config check
pnpm dev
```

Use the printed application URL, including its base path. Configuration and storage
are created locally. For LAN access configure `app.publicOrigin` to the actual
browser origin (protocol, IP, and application port, without `/main`). The first
administrator is configured in `users.initialAdmin`; a fresh default configuration
uses `nocobase` / `admin123`.

The archive contains no API credentials, sessions, or database. In Models, add
DeepSeek, enter your own API key, use `https://api.deepseek.com/v1`, fetch models,
select a chat model, and test it. The live verification used `deepseek-flash`;
use a model your current account actually offers. The header's Agent chat button
opens ordinary conversations without the release-notes scope.

The Registry installation used during verification unexpectedly downgraded the
Agents dependency. This archive already restores and locks 1.0.0-beta.29; do not
reinstall the Registry block merely to run this example.

## Business Skill

Import the separate release-notes-skill.zip from the documentation, or create a
Skill in the UI using `release-notes/SKILL.md` and add `references/style.md`.
The server Provider selects only this slug when a new conversation explicitly
chooses the `release-notes` scope. It never attaches the entire library.
The scope grants no business permissions and does not apply to Runner sessions.

A business React component can create and open the scoped conversation using
this handler. Call the hooks inside the component, wire the handler to a translated
button, disable it while pending, and show failures through the application's
existing error UI. The example verification submitted the same request through
the authenticated API and reopened the conversation in the chat UI.

```tsx
import { useApiClient } from '@nocobase/app-client';
import { useChatPanel } from '@nocobase/app-plugin-agents/client/chat';

// Inside the existing signed-in component:
const api = useApiClient();
const { openChat } = useChatPanel();
async function openReleaseNotes() {
  const { data } = await api.request<{ data: { id: string } }>({
    path: 'agents/conversations',
    method: 'POST',
    json: {
      agentId: 'online',
      title: 'Release notes with a Skill',
      config: { scope: ['release-notes'] },
      // Use the actual service identifier and enabled model in your application.
      selectedModel: { modelService: 'deepseek', model: 'deepseek-flash' },
    },
  });
  openChat({ conversationId: data.id });
}
```

Send:

```text
Read the release-notes Skill and its style guide, then draft concise release notes
in English. Supplied changes: Added model service configuration. Added a chat panel.
Fixed the missing Skills navigation entry. Verification supplied: 10 route and
locale tests passed. Do not claim any other tests ran.
```

Those are supplied demonstration facts, not instructions for the model to run tests.
Replace them with the actual changes and checks for your own release.

## Integration files

- `client/routes.ts`: exported plugin pages with original authorization.
- `client/components/agents-provider.tsx`: identity lifetime and chat provider.
- `client/layouts/app-layout.tsx`: panel docking and mobile launcher.
- `client/layouts/components/header-actions.tsx`: header launcher.
- `client/locales/en-US.ts`, `zh-CN.ts`: navigation and Registry translations.
- `server/providers/agents.ts`: named native Skill scope.
- `server/providers/index.ts`: Provider registration.
- `examples/release-notes/`: business Skill and its supporting file.

## Verification

Client/server TypeScript checks, scoped ESLint, and the route and locale suites
(10 tests) passed during development. Live checks covered DeepSeek connectivity,
a browser-submitted conversation, saved history, and Skill/Shell support-file reads.
The Runner connection form was inspected without generating registration credentials
or connecting a machine. Runner execution, all role combinations, other providers,
production builds/deployment, and attachment parsing are not verified here.
