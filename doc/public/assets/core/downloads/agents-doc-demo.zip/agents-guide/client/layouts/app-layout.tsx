import { AgentsProvider } from '#components/agents-provider';
import { ChatPanel } from '#extensions/nocobase-agent-chat/chat-panel';
import { ChatFloatingButton } from '#extensions/nocobase-agent-chat/launchers';
import { useSyncServerLocale } from '@nocobase/app-plugin-i18n/client';
import type { ReactElement } from 'react';
import type { AppClientRegisteredRoute } from '@nocobase/app-client/plugins';
import { Outlet, useLocation } from 'react-router';

import { BrandWatermark } from '#components/brand-watermark';
import { Breadcrumbs } from '#components/breadcrumbs';

import { RouteTreeProvider } from '../routing/route-context.js';

import { PageBreadcrumbProvider } from '@nocobase/app-client';
import { useTranslation } from '@nocobase/i18n/client';
import { LayoutHeader } from './components/layout-header.js';
import {
  AppSidebar,
  AppSidebarProvider,
  AppSidebarToggle,
} from './components/app-sidebar.js';
import { NavigationMenu } from './components/navigation-menu.js';
import { AppBrand } from './components/app-brand.js';
import { HeaderActions } from './components/header-actions.js';
import { AppSidebarFooter } from './components/sidebar-footer.js';
import {
  useRouteNavigation,
  selectedNavigationId,
} from '../routing/route-navigation.js';

export interface AppLayoutProps {
  readonly routes: readonly AppClientRegisteredRoute[];
}

export function AppLayout({ routes }: AppLayoutProps): ReactElement {
  // The browser decides what it renders; this tells the server the same language so its messages match.
  useSyncServerLocale();

  const { t } = useTranslation();
  const { items: menuItems, denied } = useRouteNavigation(routes);
  const selectedKey = selectedNavigationId(
    routes,
    useLocation().pathname,
    denied,
  );
  const navigationLabel = t('navigation.label', {
    defaultValue: 'Application navigation',
  });

  return (
    // The shell owns the business route tree used by its pages and navigation.
    <RouteTreeProvider routes={routes}>
      <PageBreadcrumbProvider>
        <AgentsProvider>
          <AppSidebarProvider>
            <AppSidebar label={navigationLabel} footer={<AppSidebarFooter />}>
              <NavigationMenu
                items={menuItems}
                label={navigationLabel}
                selectedKey={selectedKey}
              />
            </AppSidebar>
            <div className='flex min-w-0 flex-1 flex-col'>
              <LayoutHeader className='sticky top-0 z-40 justify-between'>
                <div className='flex min-w-0 items-center gap-3'>
                  <AppSidebarToggle />
                  <div className='md:hidden'>
                    <AppBrand />
                  </div>
                  <div className='h-5 w-px shrink-0 bg-border' />
                  {/* The current page's trail: the route tree's, or the one the page declares (`usePageBreadcrumb`). */}
                  <Breadcrumbs denied={denied} />
                </div>
                <HeaderActions />
              </LayoutHeader>
              <div className='relative flex min-h-0 flex-1'>
                <main className='app-brand-surface relative isolate min-w-0 flex-1 overflow-hidden'>
                  <BrandWatermark className='-z-10' />
                  {/* main only positions; the page scrolls in here, so a child page layer laid over main is neither
            moved by the page's scrolling nor stretched by its height. */}
                  <div className='h-full overflow-y-auto'>
                    <Outlet />
                  </div>
                </main>
                <ChatPanel />
              </div>
              <ChatFloatingButton />
            </div>
          </AppSidebarProvider>
        </AgentsProvider>
      </PageBreadcrumbProvider>
    </RouteTreeProvider>
  );
}
