import agentChat from '../extensions/nocobase-agent-chat/locales/en-US.js';
import fileUi from '../extensions/nocobase-file-component-ui/locales/en-US.js';
import type { LocaleResource } from '@nocobase/i18n';

import systemEnUS from './system/en-US.js';

const enUS = {
  // The template's own copy: the shell, the sign-in pages, shared components and the homepage. Keep it in
  // `./system/` so a template upgrade can replace it without touching the application's copy below.
  ...systemEnUS,
  ...fileUi,
  ...agentChat,
  agentDemo: {
    newSkill: 'New skill',
    skillDetails: 'Skill details',
    connectRuntime: 'Connect runtime',

    models: 'Models',
    skills: 'Skills',
    runtimes: 'Runtimes',
    agents: 'Machine agents',
    usage: 'Usage',
    releaseNotes: 'Draft release notes',
    releaseNotesError:
      'Could not open release notes. Check the Skill and model configuration, then try again.',
  },
  // The application's copy goes here, one group per feature. A shared group such as `navigation` is extended by
  // spreading the system one first, `navigation: { ...systemEnUS.navigation, orders: 'Orders' }`, since a group
  // written here replaces the system group of the same name rather than merging with it.
};

/**
 * The shape every locale of this application follows, derived from the English wording above.
 *
 * Anything a plugin does not translate falls back to this namespace, so a term defined here is reused everywhere
 * without each plugin repeating it.
 */
export type AppResource = LocaleResource<typeof enUS>;

export default enUS;
